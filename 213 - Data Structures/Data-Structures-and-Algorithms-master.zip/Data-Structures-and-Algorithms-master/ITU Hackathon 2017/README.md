This source files are the solutions to the questions asked in ITU IEEE Software Marathon 2017.
Also solutions to the corresponding HackerRank questions.
