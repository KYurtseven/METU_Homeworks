#ifndef YEAR_COMPARATOR__
#define YEAR_COMPARATOR__
#include "song.hpp"

class YearComparator
{
public:
  bool operator( )( const Song & s1, const Song & s2 ) const
  {
    //Implement this in accordance with the specifications in the homework text
  }
};

#endif
