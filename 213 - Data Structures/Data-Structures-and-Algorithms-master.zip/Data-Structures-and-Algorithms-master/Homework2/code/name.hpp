#ifndef NAME_COMPARATOR__
#define NAME_COMPARATOR__
#include "song.hpp"

class NameComparator
{
public:
  bool operator( )( const Song & s1, const Song & s2 ) const
  {
    //Implement this in accordance with the specifications in the homework text
  }
};

#endif
