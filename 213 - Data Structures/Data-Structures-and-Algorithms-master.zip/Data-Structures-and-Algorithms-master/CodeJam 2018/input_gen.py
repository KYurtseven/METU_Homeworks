from random import randint
from random import shuffle
print 1
N = 10000
print N
for i in range(0,N):
    print randint(0,1000),