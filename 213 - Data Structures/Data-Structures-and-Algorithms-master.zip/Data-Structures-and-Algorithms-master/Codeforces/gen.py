import random
print 3,3
for i in range(3):
	print 3,3