import java.io.File;
import java.sql.*;
import java.util.Properties;
import java.io.FileInputStream;

public class Query {

	// DB Connections.
	private Connection _imdb;
	private Connection _customer_db;

	// Queries.
	private String _there_exists_such_plan_sql = "SELECT * FROM \"Plan\" WHERE plan_id = ?";
	private PreparedStatement _there_exists_such_plan_statement;

	private String _there_exists_such_movie_sql = "SELECT * FROM Movies WHERE tconst = ?";
	private PreparedStatement _there_exists_such_movie_statement;

	public Query() {

	}

	public void openConnection() throws Exception {
		// DB connection configurations
		Properties configProps = new Properties();

		configProps.load(new FileInputStream(new File(this.getClass().getResource("dbconn.config").toURI())));

		String mysqlDriver			= configProps.getProperty("mysqlDriver");
		String mysqlUrl				= configProps.getProperty("mysqlUrl");
		String mysqlUser			= configProps.getProperty("mysqlUser");
		String mysqlPassword		= configProps.getProperty("mysqlPassword");

		String postgresqlDriver		= configProps.getProperty("postgresqlDriver");
		String postgresqlUrl		= configProps.getProperty("postgresqlUrl");
		String postgresqlUser		= configProps.getProperty("postgresqlUser");
		String postgresqlPassword	= configProps.getProperty("postgresqlPassword");

		// Load jdbc drivers
		Class.forName(mysqlDriver);
		Class.forName(postgresqlDriver);

		// Open connections to two databases: imdb and the customer database
		_imdb = DriverManager.getConnection(mysqlUrl, // database
				mysqlUser, // user
				mysqlPassword); // password

		_customer_db = DriverManager.getConnection(postgresqlUrl, // database
				postgresqlUser, // user
				postgresqlPassword); // password
	}

	public void closeConnection() throws Exception {
		_imdb.close();
		_customer_db.close();
	}

  // Prepare all the SQL statements in this method.
	// Preparing a statement is almost like compiling it.
	// Note that the parameters (with ?) are still not filled in.

	public void prepareStatements() throws Exception {

		_there_exists_such_plan_statement = _customer_db.prepareStatement(_there_exists_such_plan_sql);
		_there_exists_such_movie_statement = _imdb.prepareStatement(_there_exists_such_movie_sql);

		// add here more prepare statements for all the other queries you need. TODO.
	}

	// You can add more methods if you need. TODO.

	public boolean helper_there_exists_such_plan(int plan_id) throws Exception {
		_there_exists_such_plan_statement.clearParameters();
		_there_exists_such_plan_statement.setInt(1, plan_id);

		ResultSet rs = _there_exists_such_plan_statement.executeQuery();

		boolean there_exists_such_plan = rs.next();

		rs.close();

		return there_exists_such_plan;
	}

	public boolean helper_there_exists_such_movie(String movie_id) throws Exception {
		_there_exists_such_movie_statement.clearParameters();
		_there_exists_such_movie_statement.setString(1, movie_id);

		ResultSet rs = _there_exists_such_movie_statement.executeQuery();

		boolean there_exists_such_movie = rs.next();

		rs.close();

		return there_exists_such_movie;
	}

	public boolean helper_already_signed_up(String email) throws Exception {
		/* TODO */

		return false;
	}

	public boolean transaction_sign_up(String email, String password, String first_name, String last_name, int plan_id) throws Exception {
		/* TODO */

		return false;
	}

	public Customer transaction_sign_in(String email, String password) throws Exception {
		/* TODO */

		return null;
	}

	public boolean transaction_sign_out(int customer_id) throws Exception {
		/* TODO */

		return false;
	}

	public void transaction_show_plans() throws Exception {
		/* TODO */
	}

	public void transaction_show_subscription(int customer_id) throws Exception {
		/* TODO */
	}

	public boolean transaction_subscribe(int customer_id, int plan_id) throws Exception {
		/* TODO */

		return false;
	}

	public boolean transaction_watch(String movie_id, int customer_id) throws Exception {
		/* TODO */

		return false;
	}

	public void transaction_search_for_movies(int customer_id, String movie_title) throws Exception {
		/* TODO */
	}

	public void transaction_suggest_movies(int customer_id) throws Exception {
		/* TODO */
	}

}
