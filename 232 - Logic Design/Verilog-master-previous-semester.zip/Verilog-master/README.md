# Verilog
Source codes written in Logic Design course.
